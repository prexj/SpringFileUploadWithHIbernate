package com.pratikJoshi.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.web.multipart.MultipartFile;

	@Entity
	@Table(name="Avatar")
	public class Avatar implements java.io.Serializable {
		@Id
		@GeneratedValue(strategy=GenerationType.AUTO)
		@Column(name="id")
		private int id;
		
		@Column(name="name")
		private String name;
		
		@Column(name="pathOfFile")
		private String pathOfFile;
		
		
		
		
		public Avatar() {
		}


		public int getId() {
			return id;
		}


		public void setId(int id) {
			this.id = id;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getPathOfFile() {
			return pathOfFile;
		}


		public void setPathOfFile(String pathOfFile) {
			this.pathOfFile = pathOfFile;
		}


		
		
		
		
	}