package com.pratikJoshi.spring.dao;



import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pratikJoshi.spring.model.Avatar;

@Repository
public class FileUploadDao {
	@Autowired(required=true)
	private SessionFactory sessionFactory;

	public int save(Avatar avatar) {
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		int id = (Integer) session.save(avatar);
		tx.commit();
		session.close();
		
		return id;
	}

	public ArrayList<Avatar> viewAll() {
		ArrayList<Avatar> empList = new ArrayList<Avatar>();
		 /*for(Employee empBean : empList){
	            logger.info("Person List::"+p);
	        }*/
		Session session= sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		String hql = "FROM Avatar ";
		Query query = session.createQuery(hql);
		return (ArrayList<Avatar>) query.list();
	}

}
