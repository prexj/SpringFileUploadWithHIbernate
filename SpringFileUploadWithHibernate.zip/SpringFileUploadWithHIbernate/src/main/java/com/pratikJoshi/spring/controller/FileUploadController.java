package com.pratikJoshi.spring.controller;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;

import com.pratikJoshi.spring.controller.Property;
import com.pratikJoshi.spring.dao.FileUploadDao;
import com.pratikJoshi.spring.model.Avatar;
import com.pratikJoshi.spring.model.FileUpload;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

/**
 * Handles requests for the application file upload requests
 */
@Controller
public class FileUploadController {

	private static final Logger logger = LoggerFactory.getLogger(FileUploadController.class);
	
	@Autowired
	private FileUploadDao fileUpload;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		long startTime = System.currentTimeMillis();
		logger.info("Welcome home! The client locale is {}.", locale);
		long endTime   = System.currentTimeMillis();
		long totalTime = endTime - startTime;
		System.out.println("/time"+totalTime);
		return "upload";
	}
	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public String uploadFileHandler(@RequestParam("name") String name,
			@RequestParam("file") MultipartFile file) {

		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				Property property =new Property();
				// Creating the directory to store file
				//String rootPath = System.getProperty("");
				//String pathFolder = property.getPropValues();
				//String rootPath = System.getProperty("catalina.home");
				String rootPath = "D:prex";
				System.out.println("in controller pathFolder is"+rootPath);
				String rootPath1 = rootPath + File.separator + "tmpFiles";
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists()){
					dir.mkdirs();
				}
				
				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath()
						+ File.separator + name);
				String serverFile1 =dir.getAbsolutePath()+ File.separator + name;
				Avatar avatar = new Avatar();
				avatar.setName(name);
				avatar.setPathOfFile(serverFile1);
				FileUpload fu= new FileUpload();
				fu.setFile(file);
				int id = fileUpload.save(avatar);
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();

				logger.info("Server File Location="
						+ serverFile.getAbsolutePath());

				//return "You successfully uploaded file=" + name;
				return "redirect:/viewAll";
			} catch (Exception e) {
				return "You failed to upload " + name + " => " + e.getMessage();
			}
		} else {
			return "You failed to upload " + name
					+ " because the file was empty.";
		}
	}
	
	@RequestMapping(value = "/viewAll", method = RequestMethod.GET)
	public String viewAll(Locale locale, Model model) throws IOException {
		logger.info("Welcome viewAll()");
		FileUpload fu = new FileUpload();
		model.addAttribute("showAll", fileUpload.viewAll());
		//model.addAttribute("file", fu.getFile());
		Avatar avatar = new Avatar();
		byte[] bytearr = avatar.getPathOfFile().getBytes();
		ByteArrayInputStream stream = new   ByteArrayInputStream(bytearr);
		String myString = IOUtils.toString(stream, "UTF-8");
		model.addAttribute("file", myString);
		return "showAll";
	}

	/**
	 * Upload multiple file using Spring Controller
	 */
	@RequestMapping(value = "/uploadMultipleFile", method = RequestMethod.POST)
	public @ResponseBody String uploadMultipleFileHandler(@RequestParam("name") String[] names,
			@RequestParam("file") MultipartFile[] files) {

		if (files.length != names.length)
			return "Mandatory information missing";

		String message = "";
		for (int i = 0; i < files.length; i++) {
			MultipartFile file = files[i];
			String name = names[i];
			try {
				byte[] bytes = file.getBytes();

				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath()
						+ File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();

				logger.info("Server File Location="
						+ serverFile.getAbsolutePath());

				message = message + "You successfully uploaded file=" + name
						+ "<br />";
			} catch (Exception e) {
				return "You failed to upload " + name + " => " + e.getMessage();
			}
		}
		return message;
	}
}
