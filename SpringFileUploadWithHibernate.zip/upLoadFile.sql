/*
SQLyog - Free MySQL GUI v5.19
Host - 5.5.28 : Database - uploadfile
*********************************************************************
Server version : 5.5.28
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `uploadfile`;

USE `uploadfile`;

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `app_user` */

DROP TABLE IF EXISTS `app_user`;

CREATE TABLE `app_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) NOT NULL,
  `FIRST_NAME` varchar(255) NOT NULL,
  `LAST_NAME` varchar(255) NOT NULL,
  `SSO_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_hqk6uc88j3imq8u9jhro36vt3` (`SSO_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `app_user` */

/*Table structure for table `app_user1` */

DROP TABLE IF EXISTS `app_user1`;

CREATE TABLE `app_user1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `EMAIL` varchar(255) NOT NULL,
  `FIRST_NAME` varchar(255) NOT NULL,
  `LAST_NAME` varchar(255) NOT NULL,
  `SSO_ID` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_nfst9ttxda7y83d0h1qsn5oy2` (`SSO_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `app_user1` */

/*Table structure for table `avatar` */

DROP TABLE IF EXISTS `avatar`;

CREATE TABLE `avatar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `pathOfFile` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `avatar` */

insert into `avatar` (`id`,`name`,`pathOfFile`) values (1,'pratik','D:\\eclipse_k\\prex\\tmpFiles\\pratik');
insert into `avatar` (`id`,`name`,`pathOfFile`) values (2,'Production','D:\\eclipse_k\\prex\\tmpFiles\\Production');
insert into `avatar` (`id`,`name`,`pathOfFile`) values (3,'poniki','D:\\eclipse_k\\prex\\tmpFiles\\poniki');
insert into `avatar` (`id`,`name`,`pathOfFile`) values (4,'pratik','D:\\eclipse_k\\prex\\tmpFiles\\pratik');
insert into `avatar` (`id`,`name`,`pathOfFile`) values (5,'','D:\\eclipse_k\\prex\\tmpFiles\\');
insert into `avatar` (`id`,`name`,`pathOfFile`) values (6,'pratik','D:\\eclipse_k\\prex\\tmpFiles\\pratik');
insert into `avatar` (`id`,`name`,`pathOfFile`) values (7,'prex','D:\\eclipse_k\\prex\\tmpFiles\\prex');

/*Table structure for table `club` */

DROP TABLE IF EXISTS `club`;

CREATE TABLE `club` (
  `clubId` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`clubId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `club` */

insert into `club` (`clubId`,`name`) values (1,'maulik');

/*Table structure for table `documents` */

DROP TABLE IF EXISTS `documents`;

CREATE TABLE `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longblob,
  `content_type` varchar(255) DEFAULT NULL,
  `created` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `documents` */

/*Table structure for table `emp30` */

DROP TABLE IF EXISTS `emp30`;

CREATE TABLE `emp30` (
  `EMPLOYEE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FIRSTNAME` varchar(255) DEFAULT NULL,
  `LASTNAME` varchar(255) DEFAULT NULL,
  `manager_id` bigint(20) DEFAULT NULL,
  `No` int(11) DEFAULT NULL,
  PRIMARY KEY (`EMPLOYEE_ID`),
  KEY `FK_b203d14n0428gmn3bspc6anau` (`manager_id`),
  CONSTRAINT `FK_b203d14n0428gmn3bspc6anau` FOREIGN KEY (`manager_id`) REFERENCES `emp30` (`EMPLOYEE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `emp30` */

insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (1,'pratik','joshi',NULL,1);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (2,'pratik','joshi',1,1);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (3,'pratik','patel',2,2);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (4,'pratik','doifodia',3,1);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (5,'ponik','doifodia',NULL,2);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (6,'ponik','doifodia',5,1);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (7,'pratik','joshi',6,2);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (8,'pratik','joshi',7,1);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (9,'monika','joshi',NULL,3);
insert into `emp30` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`,`No`) values (10,'monika','joshi',9,1);

/*Table structure for table `emp40` */

DROP TABLE IF EXISTS `emp40`;

CREATE TABLE `emp40` (
  `EMPLOYEE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FIRSTNAME` varchar(255) DEFAULT NULL,
  `LASTNAME` varchar(255) DEFAULT NULL,
  `manager_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`EMPLOYEE_ID`),
  KEY `FK_jekcr03kfny4d3qd7a9m7qbxp` (`manager_id`),
  CONSTRAINT `FK_jekcr03kfny4d3qd7a9m7qbxp` FOREIGN KEY (`manager_id`) REFERENCES `emp40` (`EMPLOYEE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `emp40` */

insert into `emp40` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`) values (1,'pratik','joshi',NULL);
insert into `emp40` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`) values (2,'pratik','joshi',1);
insert into `emp40` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`) values (3,'pratik','jain',3);
insert into `emp40` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`) values (4,'pratik','jain',4);
insert into `emp40` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`) values (5,'ponik','jain',NULL);
insert into `emp40` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`) values (6,'ponik','jain',5);
insert into `emp40` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`manager_id`) values (7,'pratik','joshi',7);

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `EMPLOYEE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FIRSTNAME` varchar(255) DEFAULT NULL,
  `LASTNAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`EMPLOYEE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `employee` */

insert into `employee` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`) values (1,'pratik','joshi');
insert into `employee` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`) values (2,'pratik','joshi');

/*Table structure for table `employee25` */

DROP TABLE IF EXISTS `employee25`;

CREATE TABLE `employee25` (
  `EMPLOYEE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FIRSTNAME` varchar(255) DEFAULT NULL,
  `LASTNAME` varchar(255) DEFAULT NULL,
  `MANAGERNAME` varchar(255) DEFAULT NULL,
  `manager_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`EMPLOYEE_ID`),
  KEY `FK_5rtu8awm0t492lybwsa71fa0h` (`manager_id`),
  CONSTRAINT `FK_5rtu8awm0t492lybwsa71fa0h` FOREIGN KEY (`manager_id`) REFERENCES `employee25` (`EMPLOYEE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

/*Data for the table `employee25` */

insert into `employee25` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (1,'pratik','joshi',NULL,NULL);
insert into `employee25` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (2,'maulik','joshi','manger',1);
insert into `employee25` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (3,'patrik','jain',NULL,2);
insert into `employee25` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (4,'devanshi','jain',NULL,NULL);
insert into `employee25` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (5,'ponik','jain','manager',1);
insert into `employee25` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (6,'maulik','patel',NULL,2);
insert into `employee25` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (7,'vikash','varma',NULL,3);

/*Table structure for table `employee26` */

DROP TABLE IF EXISTS `employee26`;

CREATE TABLE `employee26` (
  `EMPLOYEE_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `FIRSTNAME` varchar(255) DEFAULT NULL,
  `LASTNAME` varchar(255) DEFAULT NULL,
  `MANAGERNAME` varchar(255) DEFAULT NULL,
  `manager_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`EMPLOYEE_ID`),
  KEY `FK_hc0pgppvbbtw3p8dslawvwu31` (`manager_id`),
  CONSTRAINT `FK_hc0pgppvbbtw3p8dslawvwu31` FOREIGN KEY (`manager_id`) REFERENCES `employee26` (`EMPLOYEE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `employee26` */

insert into `employee26` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (1,'pratik','joshi',NULL,NULL);
insert into `employee26` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (2,'pratik','joshi',NULL,1);
insert into `employee26` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (3,'pratik','jain',NULL,3);
insert into `employee26` (`EMPLOYEE_ID`,`FIRSTNAME`,`LASTNAME`,`MANAGERNAME`,`manager_id`) values (4,'pratik','patel',NULL,4);

/*Table structure for table `employee27` */

DROP TABLE IF EXISTS `employee27`;

CREATE TABLE `employee27` (
  `EMPLOYEE_ID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(255) DEFAULT NULL,
  `LastName` varchar(255) DEFAULT NULL,
  `EMPLOYEE_ID1` int(11) DEFAULT NULL,
  PRIMARY KEY (`EMPLOYEE_ID`),
  KEY `FK_e7w3iq4rjdrcvb9epdyj6fap0` (`EMPLOYEE_ID1`),
  CONSTRAINT `FK_e7w3iq4rjdrcvb9epdyj6fap0` FOREIGN KEY (`EMPLOYEE_ID1`) REFERENCES `employee27` (`EMPLOYEE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `employee27` */

insert into `employee27` (`EMPLOYEE_ID`,`FirstName`,`LastName`,`EMPLOYEE_ID1`) values (1,'pratik','joshi',NULL);
insert into `employee27` (`EMPLOYEE_ID`,`FirstName`,`LastName`,`EMPLOYEE_ID1`) values (2,'pratik','joshi',2);
insert into `employee27` (`EMPLOYEE_ID`,`FirstName`,`LastName`,`EMPLOYEE_ID1`) values (3,'pratik','patel',3);
insert into `employee27` (`EMPLOYEE_ID`,`FirstName`,`LastName`,`EMPLOYEE_ID1`) values (4,'pratik','jani',4);

/*Table structure for table `employee_colleague` */

DROP TABLE IF EXISTS `employee_colleague`;

CREATE TABLE `employee_colleague` (
  `EMPLOYEE_ID` bigint(20) NOT NULL,
  `COLLEAGUE_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`EMPLOYEE_ID`,`COLLEAGUE_ID`),
  KEY `FK_9ctgcbgpxrm8jrdlnuswlayyy` (`COLLEAGUE_ID`),
  CONSTRAINT `FK_4sxa4yqwkcn39p2wbw3395qva` FOREIGN KEY (`EMPLOYEE_ID`) REFERENCES `employee` (`EMPLOYEE_ID`),
  CONSTRAINT `FK_9ctgcbgpxrm8jrdlnuswlayyy` FOREIGN KEY (`COLLEAGUE_ID`) REFERENCES `employee` (`EMPLOYEE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `employee_colleague` */

insert into `employee_colleague` (`EMPLOYEE_ID`,`COLLEAGUE_ID`) values (1,1);
insert into `employee_colleague` (`EMPLOYEE_ID`,`COLLEAGUE_ID`) values (2,2);

/*Table structure for table `friends` */

DROP TABLE IF EXISTS `friends`;

CREATE TABLE `friends` (
  `friend_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  `friendship_date` date DEFAULT NULL,
  PRIMARY KEY (`friend_id`,`person_id`),
  KEY `FK_3lf925xtotplbhiuqme9o12e5` (`person_id`),
  CONSTRAINT `FK_3lf925xtotplbhiuqme9o12e5` FOREIGN KEY (`person_id`) REFERENCES `person` (`person_id`),
  CONSTRAINT `FK_idv0wqw940sm3ccr3y3mm4o92` FOREIGN KEY (`friend_id`) REFERENCES `person` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `friends` */

insert into `friends` (`friend_id`,`person_id`,`friendship_date`) values (1,1,NULL);

/*Table structure for table `person` */

DROP TABLE IF EXISTS `person`;

CREATE TABLE `person` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `person` */

insert into `person` (`person_id`,`Name`) values (1,'pratik');

/*Table structure for table `t` */

DROP TABLE IF EXISTS `t`;

CREATE TABLE `t` (
  `GroupID` int(11) NOT NULL,
  `ParentItemID` int(11) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`GroupID`),
  KEY `FK_T_Parent` (`ParentItemID`),
  CONSTRAINT `FK_T_Parent` FOREIGN KEY (`ParentItemID`) REFERENCES `t` (`GroupID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `t` */

insert into `t` (`GroupID`,`ParentItemID`,`item`) values (1,1,'room');
insert into `t` (`GroupID`,`ParentItemID`,`item`) values (2,1,'drawingroom');
insert into `t` (`GroupID`,`ParentItemID`,`item`) values (3,2,'bedroom');
insert into `t` (`GroupID`,`ParentItemID`,`item`) values (4,2,'storoom');
insert into `t` (`GroupID`,`ParentItemID`,`item`) values (5,3,'kitchen');

/*Table structure for table `team` */

DROP TABLE IF EXISTS `team`;

CREATE TABLE `team` (
  `clubid` int(11) NOT NULL,
  `teamid` int(11) NOT NULL,
  `teamname` varchar(10) NOT NULL,
  PRIMARY KEY (`clubid`,`teamid`),
  CONSTRAINT `FK_qubn7pvomd2dxhd7xdkqc49ph` FOREIGN KEY (`clubid`) REFERENCES `club` (`clubId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `team` */

insert into `team` (`clubid`,`teamid`,`teamname`) values (1,1,'teamA');

/*Table structure for table `topic` */

DROP TABLE IF EXISTS `topic`;

CREATE TABLE `topic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `parentid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `topic` */

/*Table structure for table `user_document` */

DROP TABLE IF EXISTS `user_document`;

CREATE TABLE `user_document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longblob NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_lcfjscnnac0sqjjevhlk7b7rd` (`USER_ID`),
  CONSTRAINT `FK_lcfjscnnac0sqjjevhlk7b7rd` FOREIGN KEY (`USER_ID`) REFERENCES `app_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_document` */

/*Table structure for table `user_document1` */

DROP TABLE IF EXISTS `user_document1`;

CREATE TABLE `user_document1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longblob NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `USER_ID` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_f7m8u8hiwgsoeivc9bfuw02ly` (`USER_ID`),
  CONSTRAINT `FK_f7m8u8hiwgsoeivc9bfuw02ly` FOREIGN KEY (`USER_ID`) REFERENCES `app_user1` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_document1` */

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
